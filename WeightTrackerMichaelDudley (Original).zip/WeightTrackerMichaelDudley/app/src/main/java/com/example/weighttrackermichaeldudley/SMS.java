package com.example.weighttrackermichaeldudley;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SMS extends AppCompatActivity {

    EditText editPhoneNumber;
    TextView textPermissionStatus;
    Button btnEnableSms, btnBackToData;

    private static final int SMS_PERMISSION_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        editPhoneNumber = findViewById(R.id.editPhoneNumber);
        textPermissionStatus = findViewById(R.id.textPermissionStatus);
        btnEnableSms = findViewById(R.id.btnEnableSms);
        btnBackToData = findViewById(R.id.btnBackToData);

        updatePermissionText();

        btnEnableSms.setOnClickListener(v -> checkSmsPermission());

        btnBackToData.setOnClickListener(v -> finish());
    }

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            sendGoalMessage();
        } else {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        }
    }

    private void sendGoalMessage() {
        String phoneNumber = editPhoneNumber.getText().toString();

        if (phoneNumber.isEmpty()) {
            Toast.makeText(this, "Enter a phone number.", Toast.LENGTH_SHORT).show();
            return;
        }

        String message = "Congratulations! You reached your goal weight.";

        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);

        Toast.makeText(this, "SMS notification sent.", Toast.LENGTH_SHORT).show();
        textPermissionStatus.setText("Permission Status: Granted");
    }

    private void updatePermissionText() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            textPermissionStatus.setText("Permission Status: Granted");
        } else {
            textPermissionStatus.setText("Permission Status: Not Granted");
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode,
            String[] permissions,
            int[] grantResults
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                textPermissionStatus.setText("Permission Status: Granted");
                sendGoalMessage();
            } else {
                textPermissionStatus.setText("Permission Status: Denied");
                Toast.makeText(this, "SMS denied. App will still work.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}