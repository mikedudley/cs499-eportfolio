package com.example.weighttrackermichaeldudley;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;

import androidx.appcompat.app.AppCompatActivity;

public class Data extends AppCompatActivity {

    EditText editDate, editWeight, editNotes;
    Button btnAddEntry;
    Button btnSmsSettings;
    TableLayout tableWeightLog;
    DatabaseHelper databaseHelper;

    int selectedId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        editDate = findViewById(R.id.editDate);
        editWeight = findViewById(R.id.editWeight);
        editNotes = findViewById(R.id.editNotes);
        btnAddEntry = findViewById(R.id.btnAddEntry);
        tableWeightLog = findViewById(R.id.tableWeightLog);

        databaseHelper = new DatabaseHelper(this);

        loadTable();

        btnAddEntry.setOnClickListener(v -> saveEntry());

        btnSmsSettings = findViewById(R.id.btnSmsSettings);
        btnSmsSettings.setOnClickListener(v -> {
            Intent intent = new Intent(Data.this, SMS.class);
            startActivity(intent);
        });
    }

    private void saveEntry() {
        String date = editDate.getText().toString();
        String weight = editWeight.getText().toString();
        String notes = editNotes.getText().toString();

        // INPUT VALIDATION
        if (date.isEmpty() || weight.isEmpty()) {
            Toast.makeText(this, "Please enter date and weight.", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean success;

        // NEW ENTRY
        if (selectedId == -1) {
            success = databaseHelper.addWeightEntry(date, weight, notes);

            if (success) {
                Toast.makeText(this, "Entry added.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Entry was not added.", Toast.LENGTH_SHORT).show();
            }
        } else { // EXISTING ENTRY
            success = databaseHelper.updateWeightEntry(selectedId, date, weight, notes);

            if (success) {
                Toast.makeText(this, "Entry updated.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Entry was not updated.", Toast.LENGTH_SHORT).show();
            }

            selectedId = -1;
            btnAddEntry.setText("Add Entry");
        }

        // CHECK IF USER HAS REACHED GOAL
        try {
            double currentWeight = Double.parseDouble(weight);

            // HAS REACHED GOAL WEIGHT
            if (Math.abs(currentWeight - 180) <= 1) {
                // SEND NOTIFICATION
                Toast.makeText(
                        this,
                        "Goal Weight Reached!",
                        Toast.LENGTH_LONG
                ).show();
            }
        }
        catch (Exception ignored) {
        }

        clearFields();
        loadTable();
    }

    private void loadTable() {
        while (tableWeightLog.getChildCount() > 1) {
            tableWeightLog.removeViewAt(1);
        }

        // GET ENTRIES
        Cursor cursor = databaseHelper.getAllWeightEntries();

        // LOOP OVER ENTRIES
        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String date = cursor.getString(1);
            String weight = cursor.getString(2);
            String notes = cursor.getString(3);

            // BUILD THE ROW
            TableRow row = new TableRow(this);
            row.setMinimumHeight(dp(60));

            // COLUMNS
            TextView dateText = createCell(date, 2);
            TextView weightText = createCell(weight, 1);
            TextView notesText = createCell(notes, 4);

            // DELETE BUTTON
            Button deleteButton = new Button(this);
            deleteButton.setText("X");
            deleteButton.setTextSize(16);
            deleteButton.setAllCaps(false);
            deleteButton.setMinWidth(0);
            deleteButton.setMinimumWidth(0);
            deleteButton.setMinHeight(0);
            deleteButton.setMinimumHeight(0);
            deleteButton.setPadding(0, 0, 0, 0);

            deleteButton.setLayoutParams(new TableRow.LayoutParams(
                    0,
                    60,
                    0.75f
            ));

            deleteButton.setOnClickListener(v -> {
                databaseHelper.deleteWeightEntry(id);
                Toast.makeText(this, "Entry deleted.", Toast.LENGTH_SHORT).show();
                loadTable();
            });

            row.setOnClickListener(v -> {
                selectedId = id;
                editDate.setText(date);
                editWeight.setText(weight);
                editNotes.setText(notes);
                btnAddEntry.setText("Update Entry");
            });

            row.addView(dateText);
            row.addView(weightText);
            row.addView(notesText);
            row.addView(deleteButton);

            tableWeightLog.addView(row);
        }

        cursor.close();
    }

    private TextView createCell(String text, float weight) {
        TextView textView = new TextView(this);

        textView.setText(text);
        textView.setTextSize(16);

        int padding = dp(8);
        textView.setPadding(padding, padding, padding, padding);

        textView.setLayoutParams(new TableRow.LayoutParams(
                0,
                dp(60),
                weight
        ));

        return textView;
    }

    private void clearFields() {
        editDate.setText("");
        editWeight.setText("");
        editNotes.setText("");
    }

    // HELPER TO CONVERT PX TO DP
    private int dp(int value) {
        return (int) (value * getResources().getDisplayMetrics().density);
    }
}