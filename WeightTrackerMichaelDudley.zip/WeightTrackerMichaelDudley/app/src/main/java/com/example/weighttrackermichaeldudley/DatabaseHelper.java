package com.example.weighttrackermichaeldudley;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightTracker.db";

    // Increased because the database structure has changed.
    private static final int DATABASE_VERSION = 3;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);

        // Enforce foreign-key relationships.
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        /*
         * Users table.
         *
         * Each user has a unique username, a stored password hash,
         * and an optional goal weight.
         */
        db.execSQL(
                "CREATE TABLE users (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "username TEXT NOT NULL UNIQUE, " +
                        "password_hash TEXT NOT NULL, " +
                        "goal_weight REAL" +
                        ")"
        );

        /*
         * Weight entries belong to individual users.
         *
         * user_id creates a one-to-many relationship:
         * one user can have many weight entries.
         */
        db.execSQL(
                "CREATE TABLE weights (" +
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        "user_id INTEGER NOT NULL, " +
                        "date TEXT NOT NULL, " +
                        "weight REAL NOT NULL CHECK(weight > 0), " +
                        "notes TEXT, " +
                        "FOREIGN KEY(user_id) REFERENCES users(id) " +
                        "ON DELETE CASCADE" +
                        ")"
        );

        /*
         * Index improves searches for entries belonging
         * to a particular user.
         */
        db.execSQL(
                "CREATE INDEX index_weights_user_id " +
                        "ON weights(user_id)"
        );
    }

    @Override
    public void onUpgrade(
            SQLiteDatabase db,
            int oldVersion,
            int newVersion) {

        /*
         * For this student project, rebuild the development
         * database when the schema changes.
         */
        db.execSQL("DROP TABLE IF EXISTS weights");
        db.execSQL("DROP TABLE IF EXISTS users");

        onCreate(db);
    }

    // ---------------------------------------------------------
    // USER METHODS
    // ---------------------------------------------------------

    /**
     * Creates a user account.
     * The original password is never stored directly.
     */
    public boolean addUser(
            String username,
            String password) {

        SQLiteDatabase db =
                getWritableDatabase();

        ContentValues values =
                new ContentValues();

        values.put(
                "username",
                username
        );

        values.put(
                "password_hash",
                hashPassword(password)
        );

        long result =
                db.insert(
                        "users",
                        null,
                        values
                );

        return result != -1;
    }

    /**
     * Validates a username and password.
     */
    public boolean checkUser(
            String username,
            String password) {

        SQLiteDatabase db =
                getReadableDatabase();

        String passwordHash =
                hashPassword(password);

        Cursor cursor =
                db.rawQuery(
                        "SELECT id FROM users " +
                                "WHERE username = ? " +
                                "AND password_hash = ?",
                        new String[]{
                                username,
                                passwordHash
                        }
                );

        boolean exists =
                cursor.moveToFirst();

        cursor.close();

        return exists;
    }

    /**
     * Returns the database ID belonging to a username.
     */
    public int getUserId(String username) {

        SQLiteDatabase db =
                getReadableDatabase();

        Cursor cursor =
                db.rawQuery(
                        "SELECT id FROM users " +
                                "WHERE username = ?",
                        new String[]{username}
                );

        int userId = -1;

        if (cursor.moveToFirst()) {
            userId = cursor.getInt(0);
        }

        cursor.close();

        return userId;
    }

    // ---------------------------------------------------------
    // GOAL WEIGHT METHODS
    // ---------------------------------------------------------

    /**
     * Saves a goal weight for a particular user.
     */
    public boolean updateGoalWeight(
            int userId,
            double goalWeight) {

        SQLiteDatabase db =
                getWritableDatabase();

        ContentValues values =
                new ContentValues();

        values.put(
                "goal_weight",
                goalWeight
        );

        int result =
                db.update(
                        "users",
                        values,
                        "id = ?",
                        new String[]{
                                String.valueOf(userId)
                        }
                );

        return result > 0;
    }

    /**
     * Retrieves the saved goal weight for a user.
     * Returns null if no goal has been saved.
     */
    public Double getGoalWeight(int userId) {

        SQLiteDatabase db =
                getReadableDatabase();

        Cursor cursor =
                db.rawQuery(
                        "SELECT goal_weight " +
                                "FROM users " +
                                "WHERE id = ?",
                        new String[]{
                                String.valueOf(userId)
                        }
                );

        Double goalWeight = null;

        if (cursor.moveToFirst()
                && !cursor.isNull(0)) {

            goalWeight =
                    cursor.getDouble(0);
        }

        cursor.close();

        return goalWeight;
    }

    // ---------------------------------------------------------
    // WEIGHT ENTRY METHODS
    // ---------------------------------------------------------

    /**
     * Adds a weight entry belonging to a specific user.
     */
    public boolean addWeightEntry(
            int userId,
            String date,
            double weight,
            String notes) {

        SQLiteDatabase db =
                getWritableDatabase();

        ContentValues values =
                new ContentValues();

        values.put(
                "user_id",
                userId
        );

        values.put(
                "date",
                date
        );

        values.put(
                "weight",
                weight
        );

        values.put(
                "notes",
                notes
        );

        long result =
                db.insert(
                        "weights",
                        null,
                        values
                );

        return result != -1;
    }

    /**
     * Retrieves only the weight records belonging
     * to the specified user.
     */
    public Cursor getWeightEntriesForUser(
            int userId) {

        SQLiteDatabase db =
                getReadableDatabase();

        return db.rawQuery(
                "SELECT id, date, weight, notes " +
                        "FROM weights " +
                        "WHERE user_id = ? " +
                        "ORDER BY date ASC",
                new String[]{
                        String.valueOf(userId)
                }
        );
    }

    /**
     * Updates an entry only when it belongs
     * to the logged-in user.
     */
    public boolean updateWeightEntry(
            int id,
            int userId,
            String date,
            double weight,
            String notes) {

        SQLiteDatabase db =
                getWritableDatabase();

        ContentValues values =
                new ContentValues();

        values.put(
                "date",
                date
        );

        values.put(
                "weight",
                weight
        );

        values.put(
                "notes",
                notes
        );

        int result =
                db.update(
                        "weights",
                        values,
                        "id = ? AND user_id = ?",
                        new String[]{
                                String.valueOf(id),
                                String.valueOf(userId)
                        }
                );

        return result > 0;
    }

    /**
     * Deletes an entry only when it belongs
     * to the logged-in user.
     */
    public boolean deleteWeightEntry(
            int id,
            int userId) {

        SQLiteDatabase db =
                getWritableDatabase();

        int result =
                db.delete(
                        "weights",
                        "id = ? AND user_id = ?",
                        new String[]{
                                String.valueOf(id),
                                String.valueOf(userId)
                        }
                );

        return result > 0;
    }

    // ---------------------------------------------------------
    // PASSWORD SECURITY
    // ---------------------------------------------------------

    /**
     * Converts a password into a SHA-256 hash so that
     * plaintext passwords are not stored in SQLite.
     */
    private String hashPassword(
            String password) {

        try {

            MessageDigest digest =
                    MessageDigest.getInstance(
                            "SHA-256"
                    );

            byte[] hash =
                    digest.digest(
                            password.getBytes(
                                    StandardCharsets.UTF_8
                            )
                    );

            StringBuilder hexString =
                    new StringBuilder();

            for (byte b : hash) {

                String hex =
                        Integer.toHexString(
                                0xff & b
                        );

                if (hex.length() == 1) {
                    hexString.append('0');
                }

                hexString.append(hex);
            }

            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {

            throw new IllegalStateException(
                    "SHA-256 is not available.",
                    e
            );
        }
    }
}