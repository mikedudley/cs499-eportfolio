package com.example.weighttrackermichaeldudley;

import java.util.Comparator;
import java.util.List;

public class WeightAnalyzer {

    private WeightAnalyzer() {
        // Prevent utility class instantiation.
    }

    /**
     * Sorts weight entries chronologically from oldest to newest.
     */
    public static void sortByDate(List<WeightEntry> entries) {
        entries.sort(
                Comparator.comparing(WeightEntry::getDate)
        );
    }

    /**
     * Calculates the total weight change from the first
     * recorded weight to the most recent weight.
     */
    public static double calculateTotalChange(List<WeightEntry> entries) {

        if (entries == null || entries.size() < 2) {
            return 0.0;
        }

        double startingWeight =
                entries.get(0).getWeight();

        double currentWeight =
                entries.get(entries.size() - 1).getWeight();

        return currentWeight - startingWeight;
    }

    /**
     * Calculates the distance between the most recent
     * weight and the user's goal weight.
     */
    public static double calculateDistanceFromGoal(
            List<WeightEntry> entries,
            double goalWeight) {

        if (entries == null || entries.isEmpty()) {
            return 0.0;
        }

        double currentWeight =
                entries.get(entries.size() - 1).getWeight();

        return Math.abs(currentWeight - goalWeight);
    }

    /**
     * Calculates the average weight over the most recent
     * number of entries specified by windowSize.
     */
    public static double calculateMovingAverage(
            List<WeightEntry> entries,
            int windowSize) {

        if (entries == null
                || entries.isEmpty()
                || windowSize <= 0) {

            return 0.0;
        }

        int startIndex =
                Math.max(0, entries.size() - windowSize);

        double total = 0.0;
        int count = 0;

        for (int i = startIndex; i < entries.size(); i++) {
            total += entries.get(i).getWeight();
            count++;
        }

        return count == 0
                ? 0.0
                : total / count;
    }

    /**
     * Determines whether the user's most recent weight
     * increased, decreased, or stayed the same.
     */
    public static String determineTrend(List<WeightEntry> entries) {

        if (entries == null || entries.size() < 2) {
            return "Not enough data";
        }

        double previousWeight =
                entries.get(entries.size() - 2).getWeight();

        double currentWeight =
                entries.get(entries.size() - 1).getWeight();

        if (currentWeight < previousWeight) {
            return "Decreasing";
        } else if (currentWeight > previousWeight) {
            return "Increasing";
        } else {
            return "No Change";
        }
    }
}