package com.example.weighttrackermichaeldudley;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText editUsername;
    private EditText editPassword;

    private Button btnLogin;
    private Button btnCreateAccount;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        editUsername =
                findViewById(R.id.editUsername);

        editPassword =
                findViewById(R.id.editPassword);

        btnLogin =
                findViewById(R.id.btnLogin);

        btnCreateAccount =
                findViewById(R.id.btnCreateAccount);

        databaseHelper =
                new DatabaseHelper(this);

        // -------------------------------------------------
        // CREATE ACCOUNT
        // -------------------------------------------------

        btnCreateAccount.setOnClickListener(v -> {

            String username =
                    editUsername
                            .getText()
                            .toString()
                            .trim();

            String password =
                    editPassword
                            .getText()
                            .toString();

            if (username.isEmpty()) {

                editUsername.setError(
                        "Please enter a username."
                );

                editUsername.requestFocus();

                return;
            }

            if (password.isEmpty()) {

                editPassword.setError(
                        "Please enter a password."
                );

                editPassword.requestFocus();

                return;
            }

            boolean inserted =
                    databaseHelper.addUser(
                            username,
                            password
                    );

            if (inserted) {

                Toast.makeText(
                        this,
                        "Account created.",
                        Toast.LENGTH_SHORT
                ).show();

            } else {

                Toast.makeText(
                        this,
                        "Username already exists.",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });

        // -------------------------------------------------
        // LOGIN
        // -------------------------------------------------

        btnLogin.setOnClickListener(v -> {

            String username =
                    editUsername
                            .getText()
                            .toString()
                            .trim();

            String password =
                    editPassword
                            .getText()
                            .toString();

            if (username.isEmpty()
                    || password.isEmpty()) {

                Toast.makeText(
                        this,
                        "Enter your username and password.",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            boolean validLogin =
                    databaseHelper.checkUser(
                            username,
                            password
                    );

            if (validLogin) {

                int userId =
                        databaseHelper.getUserId(
                                username
                        );

                if (userId == -1) {

                    Toast.makeText(
                            this,
                            "Unable to load user account.",
                            Toast.LENGTH_SHORT
                    ).show();

                    return;
                }

                Toast.makeText(
                        this,
                        "Login successful.",
                        Toast.LENGTH_SHORT
                ).show();

                Intent intent =
                        new Intent(
                                MainActivity.this,
                                Data.class
                        );

                /*
                 * Pass the user's database ID so Data can
                 * query only that user's records.
                 */
                intent.putExtra(
                        "USER_ID",
                        userId
                );

                startActivity(intent);

            } else {

                Toast.makeText(
                        this,
                        "Invalid login.",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });
    }
}