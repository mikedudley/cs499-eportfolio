package com.example.weighttrackermichaeldudley;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoField;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Data extends AppCompatActivity {

    private EditText editGoalWeight;
    private EditText editDate;
    private EditText editWeight;
    private EditText editNotes;

    private TextView textWeightStats;

    private Button btnAddEntry;
    private Button btnSmsSettings;

    private TableLayout tableWeightLog;
    private DatabaseHelper databaseHelper;

    private int selectedId = -1;
    private int userId = -1;

    /*
     * Dates are displayed to the user in a short format.
     * Example: 9/1/26
     */
    private static final DateTimeFormatter DISPLAY_DATE_FORMAT =
            DateTimeFormatter.ofPattern("M/d/yy");

    /*
     * Dates are stored consistently in the existing database.
     * Example: 09/01/2026
     */
    private static final DateTimeFormatter DATABASE_DATE_FORMAT =
            DateTimeFormatter.ofPattern("MM/dd/yyyy");

    /*
     * Allows flexible user input such as:
     * 9/1/26
     * 09/01/26
     * 9/1/2026
     * 09/01/2026
     */
    private static final DateTimeFormatter INPUT_DATE_FORMAT =
            new DateTimeFormatterBuilder()
                    .appendPattern("M/d/")
                    .appendValueReduced(
                            ChronoField.YEAR,
                            2,
                            4,
                            2000
                    )
                    .toFormatter();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        // Connect Java variables to XML views.
        editGoalWeight = findViewById(R.id.editGoalWeight);
        editDate = findViewById(R.id.editDate);
        editWeight = findViewById(R.id.editWeight);
        editNotes = findViewById(R.id.editNotes);

        textWeightStats = findViewById(R.id.textWeightStats);

        btnAddEntry = findViewById(R.id.btnAddEntry);
        btnSmsSettings = findViewById(R.id.btnSmsSettings);

        tableWeightLog = findViewById(R.id.tableWeightLog);

        databaseHelper = new DatabaseHelper(this);

        userId = getIntent().getIntExtra(
                "USER_ID",
                -1
        );

        if (userId == -1) {

            Toast.makeText(
                    this,
                    "No user account was provided.",
                    Toast.LENGTH_LONG
            ).show();

            finish();

            return;
        }

        // Display existing weight entries.
        loadGoalWeight();
        loadTable();

        btnAddEntry.setOnClickListener(v -> saveEntry());

        btnSmsSettings.setOnClickListener(v -> {
            Intent intent = new Intent(Data.this, SMS.class);
            startActivity(intent);
        });

        /*
         * Recalculate the progress summary when the user finishes
         * editing the goal weight.
         */
        editGoalWeight.setOnFocusChangeListener((v, hasFocus) -> {
            if (!hasFocus) {
                loadTable();
            }
        });
    }

    /**
     * Adds a new weight entry or updates the selected entry.
     */
    private void saveEntry() {

        String dateText =
                editDate.getText().toString().trim();

        String weightText =
                editWeight.getText().toString().trim();

        String notes =
                editNotes.getText().toString().trim();

        String goalWeightText =
                editGoalWeight.getText().toString().trim();

        // ----------------------------
        // Validate goal weight
        // ----------------------------

        if (goalWeightText.isEmpty()) {
            editGoalWeight.setError(
                    "Please enter a goal weight."
            );
            editGoalWeight.requestFocus();
            return;
        }

        double goalWeight;

        try {
            goalWeight =
                    Double.parseDouble(goalWeightText);

            if (goalWeight <= 0) {
                editGoalWeight.setError(
                        "Goal weight must be greater than zero."
                );
                editGoalWeight.requestFocus();
                return;
            }

        } catch (NumberFormatException e) {
            editGoalWeight.setError(
                    "Please enter a valid goal weight."
            );
            editGoalWeight.requestFocus();
            return;
        }

        boolean goalSaved =
                databaseHelper.updateGoalWeight(
                        userId,
                        goalWeight
                );

        if (!goalSaved) {

            Toast.makeText(
                    this,
                    "Goal weight could not be saved.",
                    Toast.LENGTH_SHORT
            ).show();

            return;
        }

        // ----------------------------
        // Validate date
        // ----------------------------

        if (dateText.isEmpty()) {
            editDate.setError(
                    "Please enter a date."
            );
            editDate.requestFocus();
            return;
        }

        LocalDate parsedDate;

        try {
            parsedDate =
                    LocalDate.parse(
                            dateText,
                            INPUT_DATE_FORMAT
                    );

        } catch (DateTimeParseException e) {
            editDate.setError(
                    "Enter a valid date, such as 9/1/26."
            );
            editDate.requestFocus();
            return;
        }

        // ----------------------------
        // Validate weight
        // ----------------------------

        if (weightText.isEmpty()) {
            editWeight.setError(
                    "Please enter a weight."
            );
            editWeight.requestFocus();
            return;
        }

        double currentWeight;

        try {
            currentWeight =
                    Double.parseDouble(weightText);

            if (currentWeight <= 0) {
                editWeight.setError(
                        "Weight must be greater than zero."
                );
                editWeight.requestFocus();
                return;
            }

        } catch (NumberFormatException e) {
            editWeight.setError(
                    "Please enter a valid weight."
            );
            editWeight.requestFocus();
            return;
        }

        /*
         * Normalize the date before storing it in SQLite.
         */
        String databaseDate =
                parsedDate.format(
                        DATABASE_DATE_FORMAT
                );

        boolean success;

        // ----------------------------
        // Add new entry
        // ----------------------------

        if (selectedId == -1) {

            success =
                    databaseHelper.addWeightEntry(
                            userId,
                            databaseDate,
                            currentWeight,
                            notes
                    );

            if (success) {

                Toast.makeText(
                        this,
                        "Entry added.",
                        Toast.LENGTH_SHORT
                ).show();

            } else {

                Toast.makeText(
                        this,
                        "Entry was not added.",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

        } else {

            // ----------------------------
            // Update existing entry
            // ----------------------------

            success =
                    databaseHelper.updateWeightEntry(
                            selectedId,
                            userId,
                            databaseDate,
                            currentWeight,
                            notes
                    );

            if (success) {

                Toast.makeText(
                        this,
                        "Entry updated.",
                        Toast.LENGTH_SHORT
                ).show();

            } else {

                Toast.makeText(
                        this,
                        "Entry was not updated.",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            resetSelection();
        }

        // ----------------------------
        // Check goal progress
        // ----------------------------

        if (Math.abs(
                currentWeight - goalWeight
        ) <= 1.0) {

            Toast.makeText(
                    this,
                    "Goal Weight Reached!",
                    Toast.LENGTH_LONG
            ).show();
        }

        clearEntryFields();
        loadTable();
    }

    /**
     * Loads database records into an ArrayList of WeightEntry
     * objects, sorts them chronologically, analyzes the data,
     * and displays the resulting entries.
     */
    private void loadTable() {

        List<WeightEntry> entries =
                new ArrayList<>();

        /*
         * Remove previously displayed rows while preserving
         * the table header.
         */
        while (tableWeightLog.getChildCount() > 1) {
            tableWeightLog.removeViewAt(1);
        }

        Cursor cursor =
                databaseHelper.getWeightEntriesForUser(
                        userId
                );

        /*
         * Convert database records into WeightEntry objects.
         */
        while (cursor.moveToNext()) {

            int id =
                    cursor.getInt(0);

            String dateText =
                    cursor.getString(1);

            String weightText =
                    cursor.getString(2);

            String notes =
                    cursor.getString(3);

            try {

                LocalDate date =
                        LocalDate.parse(
                                dateText,
                                DATABASE_DATE_FORMAT
                        );

                double weight =
                        Double.parseDouble(
                                weightText
                        );

                WeightEntry entry =
                        new WeightEntry(
                                id,
                                date,
                                weight,
                                notes
                        );

                entries.add(entry);

            } catch (
                    DateTimeParseException
                    | NumberFormatException e) {

                /*
                 * Skip invalid legacy records instead of
                 * allowing them to crash the application.
                 */
            }
        }

        cursor.close();

        /*
         * Sort chronologically from oldest to newest.
         */
        WeightAnalyzer.sortByDate(entries);

        /*
         * Traverse the sorted collection and display
         * each WeightEntry.
         */
        for (WeightEntry entry : entries) {
            createWeightRow(entry);
        }

        /*
         * Analyze the collection and update the UI.
         */
        updateProgressSummary(entries);
    }

    /**
     * Creates a table row for one WeightEntry.
     */
    private void createWeightRow(
            WeightEntry entry) {

        TableRow row =
                new TableRow(this);

        row.setMinimumHeight(
                dp(60)
        );

        TextView dateText =
                createCell(
                        entry.getDate()
                                .format(
                                        DISPLAY_DATE_FORMAT
                                ),
                        2
                );

        TextView weightText =
                createCell(
                        String.format(
                                Locale.US,
                                "%.1f",
                                entry.getWeight()
                        ),
                        1
                );

        TextView notesText =
                createCell(
                        entry.getNotes(),
                        4
                );

        // ----------------------------
        // Delete button
        // ----------------------------

        Button deleteButton =
                new Button(this);

        deleteButton.setText("X");
        deleteButton.setTextSize(16);
        deleteButton.setAllCaps(false);

        deleteButton.setMinWidth(0);
        deleteButton.setMinimumWidth(0);
        deleteButton.setMinHeight(0);
        deleteButton.setMinimumHeight(0);

        deleteButton.setPadding(
                0,
                0,
                0,
                0
        );

        deleteButton.setLayoutParams(
                new TableRow.LayoutParams(
                        0,
                        dp(60),
                        0.75f
                )
        );

        deleteButton.setOnClickListener(v -> {

            databaseHelper.deleteWeightEntry(
                    entry.getId(),
                    userId
            );

            Toast.makeText(
                    this,
                    "Entry deleted.",
                    Toast.LENGTH_SHORT
            ).show();

            /*
             * If the deleted entry was being edited,
             * return to Add mode.
             */
            if (selectedId == entry.getId()) {
                resetSelection();
                clearEntryFields();
            }

            loadTable();
        });

        // ----------------------------
        // Row selection / editing
        // ----------------------------

        row.setOnClickListener(v -> {

            selectedId =
                    entry.getId();

            editDate.setText(
                    entry.getDate()
                            .format(
                                    DISPLAY_DATE_FORMAT
                            )
            );

            editWeight.setText(
                    String.format(
                            Locale.US,
                            "%.1f",
                            entry.getWeight()
                    )
            );

            editNotes.setText(
                    entry.getNotes()
            );

            btnAddEntry.setText(
                    "Update Entry"
            );
        });

        row.addView(dateText);
        row.addView(weightText);
        row.addView(notesText);
        row.addView(deleteButton);

        tableWeightLog.addView(row);
    }

    /**
     * Calculates and displays statistics based on
     * the sorted WeightEntry collection.
     */
    private void updateProgressSummary(
            List<WeightEntry> entries) {

        if (entries == null
                || entries.isEmpty()) {

            textWeightStats.setText(
                    "Add weight entries to view your progress."
            );

            return;
        }

        double totalChange =
                WeightAnalyzer
                        .calculateTotalChange(
                                entries
                        );

        double movingAverage =
                WeightAnalyzer
                        .calculateMovingAverage(
                                entries,
                                3
                        );

        String trend =
                WeightAnalyzer
                        .determineTrend(
                                entries
                        );

        StringBuilder summary =
                new StringBuilder();

        summary.append("Total Change: ")
                .append(
                        String.format(
                                Locale.US,
                                "%.1f",
                                totalChange
                        )
                )
                .append(" lbs\n");

        summary.append("3-Entry Average: ")
                .append(
                        String.format(
                                Locale.US,
                                "%.1f",
                                movingAverage
                        )
                )
                .append(" lbs\n");

        summary.append("Recent Trend: ")
                .append(trend);

        /*
         * Goal distance is only displayed when
         * a valid goal has been entered.
         */
        String goalText =
                editGoalWeight
                        .getText()
                        .toString()
                        .trim();

        if (!goalText.isEmpty()) {

            try {

                double goalWeight =
                        Double.parseDouble(
                                goalText
                        );

                if (goalWeight > 0) {

                    double distanceFromGoal =
                            WeightAnalyzer
                                    .calculateDistanceFromGoal(
                                            entries,
                                            goalWeight
                                    );

                    summary.append(
                                    "\nDistance From Goal: "
                            )
                            .append(
                                    String.format(
                                            Locale.US,
                                            "%.1f",
                                            distanceFromGoal
                                    )
                            )
                            .append(" lbs");
                }

            } catch (NumberFormatException ignored) {
                // Do not display distance for invalid goal input.
            }
        }

        textWeightStats.setText(
                summary.toString()
        );
    }

    /**
     * Creates a TextView used as a table cell.
     */
    private TextView createCell(
            String text,
            float weight) {

        TextView textView =
                new TextView(this);

        textView.setText(text);
        textView.setTextSize(16);

        int padding =
                dp(8);

        textView.setPadding(
                padding,
                padding,
                padding,
                padding
        );

        textView.setLayoutParams(
                new TableRow.LayoutParams(
                        0,
                        dp(60),
                        weight
                )
        );

        return textView;
    }

    /**
     * Clears only the weight-entry fields.
     * The goal weight remains because it applies
     * to the user's overall progress.
     */
    private void clearEntryFields() {

        editDate.setText("");
        editWeight.setText("");
        editNotes.setText("");
    }

    /**
     * Returns the interface to new-entry mode.
     */
    private void resetSelection() {

        selectedId = -1;

        btnAddEntry.setText(
                "Add Entry"
        );
    }

    /**
     * Converts density-independent pixels to pixels.
     */
    private int dp(int value) {

        return (int) (
                value
                        * getResources()
                        .getDisplayMetrics()
                        .density
        );
    }

    /**
     * Loads the logged-in user's saved goal weight
     * from the database.
     */
    private void loadGoalWeight() {

        Double savedGoalWeight =
                databaseHelper.getGoalWeight(
                        userId
                );

        if (savedGoalWeight != null) {

            editGoalWeight.setText(
                    String.format(
                            Locale.US,
                            "%.1f",
                            savedGoalWeight
                    )
            );
        }
    }
}