package com.example.weighttrackermichaeldudley;

import java.time.LocalDate;

public class WeightEntry {

    private final int id;
    private final LocalDate date;
    private final double weight;
    private final String notes;

    public WeightEntry(
            int id,
            LocalDate date,
            double weight,
            String notes) {

        this.id = id;
        this.date = date;
        this.weight = weight;
        this.notes = notes;
    }

    public int getId() {
        return id;
    }

    public LocalDate getDate() {
        return date;
    }

    public double getWeight() {
        return weight;
    }

    public String getNotes() {
        return notes;
    }
}